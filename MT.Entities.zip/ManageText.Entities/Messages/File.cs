﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    public class File: IEntityBase, IAuditable
    {

        public int ID { get; set; }
        public string Path { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string MIME { get; set; }


        //  Customer Id details 
        //public int UserId { get; set; }
        //public virtual User User { get; set; }

        //  Company Id details 
        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }



        //Audit Columumns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
    }
}
