﻿using ManageText.Entities.Common;
using ManageText.Entities.Messages;
using ManageText.Entities.Payment;
using ManageText.Entities.Subscriptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Account
{
    public class Company : IEntityBase, IAuditable
    {

        public Company()
        {
            CompanySubscriptions = new List<Subscription>();
            CompanyInvoices = new List<Invoice>();
            CompanyCreditCards = new List<CreditCard>();
            CompanyAddresses = new List<Address>();
            CompanySubscribers = new List<Subscriber>();
            CompanyUsers = new List<User>();
        }
           



        public int ID { get; set; }

        public string Name { get; set; }
        public string CompanyEmail { get; set; }

        public string Image { get; set; }

        public string Description { get; set; }



        /// <summary>
        /// Determines whether [has payment details].
        /// </summary>
        /// <returns></returns>
        public bool HasPaymentDetails()
        {
            return CompanyCreditCards != null && CompanyCreditCards.Any();
        }


        public virtual ICollection<User> CompanyUsers { get; set; }
        public virtual ICollection<Subscription> CompanySubscriptions { get; set; }
        public virtual IList<Invoice> CompanyInvoices { get; set; }
        public virtual IList<CreditCard> CompanyCreditCards { get; set; } // The actual credit card number is not stored! 
        //public virtual BillingAddress BillingAddress { get; set; }
        public ICollection<Address> CompanyAddresses { get; set; }
        public virtual ICollection<Subscriber> CompanySubscribers { get; set; }




        //Audit Columns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }

    }
}
