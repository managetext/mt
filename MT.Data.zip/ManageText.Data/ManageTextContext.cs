﻿using ManageText.Data.Configurations;
using ManageText.Entities.Account;
using ManageText.Entities.Common;
using ManageText.Entities.Messages;
using ManageText.Entities.Payment;
using ManageText.Entities.Subscriptions;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data
{
    public class ManageTextContext : DbContext
    {
        public ManageTextContext()
           : base("ManageText")
        {
            Database.SetInitializer<ManageTextContext>(null);
        }


        #region Entity Sets
        public IDbSet<User> UserSet { get; set; }
        public IDbSet<Role> RoleSet { get; set; }
        public IDbSet<UserRole> UserRoleSet { get; set; }
        public IDbSet<UserFile> UserFileSet { get; set; }

        //Common
        public IDbSet<Address> AddressSet { get; set; }
        public IDbSet<Error> ErrorSet { get; set; }

        //Messages
        public IDbSet<Campaign> CampaignSet { get; set; }
        public IDbSet<File> FileSet { get; set; }
        public IDbSet<Message> MessageSet { get; set; }
        public IDbSet<Keyword> KeywordSet { get; set; }
        public IDbSet<MessageType> MessageTypeSet { get; set; }
        public IDbSet<Subscriber> SubscriberSet { get; set; }

        //Payment
        //public IDbSet<BillingAddress> BillingAddressSet { get; set; }
        public IDbSet<CreditCard> CreditCardSet { get; set; }
        public IDbSet<Invoice> InvoiceSet { get; set; }
        public IDbSet<StripeAccount> StripeAccountSet { get; set; }

        //Subscription
        public IDbSet<Subscription> SubscriptionSet { get; set; }
        public IDbSet<SubscriptionPlan> SubscriptionPlanSet { get; set; }
        public IDbSet<SubscriptionPlanProperty> SubscriptionPlanPropertySet { get; set; }

        #endregion

        public virtual void Commit()
        {
            base.SaveChanges();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

           

            //Account
            modelBuilder.Configurations.Add(new UserConfiguration());
            modelBuilder.Configurations.Add(new RoleConfiguration());
            modelBuilder.Configurations.Add(new UserRoleConfiguration());
            modelBuilder.Configurations.Add(new UserFileConfiguration());


            //Common
            modelBuilder.Configurations.Add(new AddressConfiguration());


            //Messages
            modelBuilder.Configurations.Add(new CampaignConfiguration());
            modelBuilder.Configurations.Add(new KeywordConfiguration());


            modelBuilder.Ignore<BillingAddress>();

        }

        }
}
