﻿using ManageText.Entities.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Messages
{
    public class Campaign : IEntityBase, IAuditable
    {

        public Campaign()
        {
          
            Keywords = new List<Keyword>();
            Messages = new List<Message>();
            
        }


        public int ID { get; set; }
        //Campaign Name
        public string Name { get; set; }
        public string Comments { get; set; }
        //Campaign Message  [copied from keyword or own]
        public string Message { get; set; }



        public int MessageTypeId { get; set; }
        public virtual MessageType MessageType { get; set; }

        public int? FileId { get; set; }
        public virtual File File { get; set; }

        

        public virtual ICollection<Keyword> Keywords { get; set; }
        public virtual ICollection<Message> Messages { get; set; }

     
        public bool Schedule { get; set; }
        public DateTime? ScheduledAt { get; set; }


        //  Customer Id details 
        //public int UserId { get; set; }
        //public virtual User User { get; set; }


        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }


        //Audit Columns
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }

    }
}
