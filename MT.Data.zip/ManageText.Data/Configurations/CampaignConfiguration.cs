﻿using ManageText.Entities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Configurations
{
    public class CampaignConfiguration : EntityBaseConfiguration<Campaign>
    {

        public CampaignConfiguration()
        {


            Property(c => c.Name).IsRequired().HasMaxLength(1000);
            Property(c => c.Comments).IsOptional().HasMaxLength(1000);
            Property(c => c.Message).IsRequired();
            Property(c => c.MessageTypeId).IsRequired();
            Property(c => c.CompanyId).IsRequired();

            Property(c => c.CreatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.CreatedDate).IsOptional();
            Property(c => c.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(c => c.UpdatedDate).IsOptional();
        }
    }
}
