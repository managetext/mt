﻿using ManageText.Entities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Data.Configurations
{
    public class KeywordConfiguration : EntityBaseConfiguration<Keyword>
    {
        public KeywordConfiguration()
        {
            Property(k => k.Name).IsRequired().HasMaxLength(100);
           
            Property(k => k.Approved).IsRequired();
            Property(k => k.ApprovedDate).IsOptional();
            Property(k => k.ApproveddBy).IsOptional();


            Property(k => k.CreatedBy).IsOptional().HasMaxLength(50);
            Property(k => k.CreatedDate).IsOptional();
            Property(k => k.UpdatedBy).IsOptional().HasMaxLength(50);
            Property(k => k.UpdatedDate).IsOptional();
        }
    }
}

