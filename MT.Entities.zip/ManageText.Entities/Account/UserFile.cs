﻿using ManageText.Entities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Account
{
    public class UserFile : IEntityBase
    {
        public int ID { get; set; }
        public int UserId { get; set; }
        public int FileId { get; set; }
        public virtual File File { get; set; }
    }
}
