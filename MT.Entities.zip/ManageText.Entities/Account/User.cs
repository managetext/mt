﻿using ManageText.Entities.Common;
using ManageText.Entities.Messages;
using ManageText.Entities.Payment;
using ManageText.Entities.Subscriptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageText.Entities.Account
{
    public class User : IEntityBase
    {
        public User()
        {
            UserRoles = new List<UserRole>();
            UserFiles = new List<File>();

            //UserSubscriptions = new List<Subscription>();
            //UserInvoices = new List<Invoice>();
            //UserCreditCards = new List<CreditCard>();
            //UserBillingAddresses = new List<Address>();
            //UserSubscribers = new List<Subscriber>();
        }
        public int ID { get; set; }
        public string Username { get; set; }

        public string Email { get; set; }



        public string FirstName { get; set; }     
        public string LastName { get; set; }
       


        public string CompanyName { get; set; }
        public string PhoneNumber { get; set; }
       

        public string Comments { get; set; }
        public string Description { get; set; }



        public string HashedPassword { get; set; }
        public string Salt { get; set; }
        public bool IsLocked { get; set; }
        public DateTime DateCreated { get; set; }
      


        public virtual DateTime? RegistrationDate { get; set; }      
        public virtual DateTime? LastLoginTime { get; set; }     
        public string StripeCustomerId { get; set; }
        

     
        public string IPAddress { get; set; }
        public string IPAddressCountry { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this "User" is delinquent. Whether or not the latest charge for the customer’s latest invoice has failed
        /// </summary>
        /// <value>
        ///   <c>true</c> if delinquent; otherwise, <c>false</c>.
        /// </value>
        public bool Delinquent { get; set; }

        /// <summary>
        /// Gets or sets the lifetime value for the customer (total spent in the app)
        /// </summary>
        /// <value>
        /// The lifetime value.
        /// </value>
        public decimal LifetimeValue { get; set; }
              

        /// <summary>
        /// Determines whether [has user details].
        /// </summary>
        /// <returns></returns>
        public bool HasUserDetails()
        {
            if (string.IsNullOrEmpty(FirstName) ||
                string.IsNullOrEmpty(LastName))
            {
                return false;
            }

            return true;
        }

        ///// <summary>
        ///// Determines whether [has payment details].
        ///// </summary>
        ///// <returns></returns>
        //public bool HasPaymentDetails()
        //{
        //    return UserCreditCards != null && UserCreditCards.Any();
        //}



        //ASP NET USER PROPERTIES

        public bool? PhoneNumberConfirmed { get; set; }
        public bool? EmailConfirmed { get; set; }
        public bool? TwoFactorEnabled { get; set; }
      


        /// <summary>
        /// User Roles Details , Admin , Customer, Employee.
        /// </summary>
        public virtual ICollection<UserRole> UserRoles { get; set; }
        public virtual ICollection<File> UserFiles { get; set; }

        //  Company Id details 
        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }



        //public virtual ICollection<Subscription> UserSubscriptions { get; set; }
        //public virtual IList<Invoice> UserInvoices { get; set; }
        //public virtual IList<CreditCard> UserCreditCards { get; set; } // The actual credit card number is not stored! 
        ////public virtual BillingAddress BillingAddress { get; set; }
        //public ICollection<Address> UserBillingAddresses { get; set; }
        //public virtual ICollection<Subscriber> UserSubscribers { get; set; }


    }
}
